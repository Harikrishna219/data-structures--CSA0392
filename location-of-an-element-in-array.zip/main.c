#include <stdio.h>
int main()
{
	int n[10]={1,14,16,23,25,30};
	int i;
	for(i=0; i<=5; i++)
	{
		if(n[i]==16)
		{
		printf("%d", i);	
		}
	}
}