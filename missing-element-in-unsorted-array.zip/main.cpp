#include <stdio.h>
#include <stdbool.h>
void findMissingElements(int arr[], int size, int range) {
    bool hash[range + 1]; 
    for (int i = 0; i <= range; i++) {
        hash[i] = false;
    }
    for (int i = 0; i < size; i++) {
        if (arr[i] >= 0 && arr[i] <= range) {
            hash[arr[i]] = true;
        }
    }
    printf("Missing elements in the array: ");
    for (int i = 0; i <= range; i++) {
        if (!hash[i]) {
            printf("%d ", i);
        }
    }
    printf("\n");
}

int main() {
    int arr[] = {4, 1, 3, 6, 8};
    int size = sizeof(arr) / sizeof(arr[0]);
    int range = 8; 

    findMissingElements(arr, size, range);

    return 0;
}
