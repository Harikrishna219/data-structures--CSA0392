#include <stdio.h>
#include <string.h>

int main() {
    char input[100];
    int charCount[256] = {0}; 
    
    printf("Enter a string: ");
    fgets(input, sizeof(input), stdin);
    
    int length = strlen(input);
    for (int i = 0; i < length; i++) {
        charCount[input[i]]++;
    }
    printf("Repeated characters and their indices:\n");
    for (int i = 0; i < length; i++) {
        if (charCount[input[i]] > 1) {
            printf("%c at index %d\n", input[i], i);
            charCount[input[i]] = 0; 
        }
    }
    
    return 0;
}
