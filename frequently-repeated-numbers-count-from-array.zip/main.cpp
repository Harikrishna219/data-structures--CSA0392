#include <stdio.h>

int main() {
    int arr[100]; 
    int n;
    printf("Enter the size of the array: ");
    scanf("%d", &n);
    printf("Enter %d elements:\n", n);
    for (int i = 0; i < n; i++) {
        scanf("%d", &arr[i]);
    }
    int freq[100] = {0}; 

    for (int i = 0; i < n; i++) {
        freq[arr[i]]++;
    }
    printf("Frequently repeated numbers and their counts:\n");
    for (int i = 0; i < 100; i++) {
        if (freq[i] > 1) {
            printf("%d occurs %d times\n", i, freq[i]);
        }
    }

    return 0;
}
